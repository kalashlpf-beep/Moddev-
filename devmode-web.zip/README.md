# Dev Mode Web

Page Web avec un bouton qui tente d'ouvrir directement les Options pour les développeurs Android via un intent.

## Utilisation

Héberge simplement `index.html` sur ton hébergeur Web.

## Limitation Android

Une page Web ne peut pas activer silencieusement le mode développeur. Elle peut seulement tenter d'ouvrir l'écran des paramètres.
